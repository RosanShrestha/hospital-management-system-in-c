void WelcomeScreen();
int LogIn();
void Title();
int Add_new_patients();
void Show_PatDetails();
int Add_new_doctor();
void Show_PatDetails();
int SearchPatientById();
int SearchDoctorById();
void DeletePatients();
void DeleteDoctor();
void Update_patient();
void Update_doctor();
void Exit();
//void Update_fName();

